package p2.submibot.resources;

public class Response {
	private String id;

	@Override
	public String toString() {
		return this.id;
	}
}
