package p2.submibot.resources;

public class Submission {
	private String preview_url;

	@Override
	public String toString() {
		return this.preview_url;
	}
}
