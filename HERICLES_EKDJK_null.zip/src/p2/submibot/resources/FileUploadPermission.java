package p2.submibot.resources;

public class FileUploadPermission {
	private String upload_url;
	
	@Override
	public String toString() {
		return this.upload_url;
	}
}
