# SubmiBot
Um plugin do eclipse para facilitar as submissões em laboratório de programação 2
